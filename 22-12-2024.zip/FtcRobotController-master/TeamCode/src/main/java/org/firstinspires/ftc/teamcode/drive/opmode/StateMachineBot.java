package org.firstinspires.ftc.teamcode.drive.opmode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;

@TeleOp(name = "StateMachineBot", group = "Robot")
public class StateMachineBot extends LinearOpMode {
    // Hardware declarations
    private DcMotor intakeSlide;
    private DcMotor outtakeSlide;
    private Servo intakeClaw;
    private Servo outtakeClaw;
    private Servo intakeArm;
    private Servo outtakeArm;

    // Timer for state transitions
    private ElapsedTime stateTimer;
    private int transferStep = 0;
    private int outakeStep = 0;

    // State enum
    /*
    A button: Init → ToIntake, Transfer → Outake
    B button: ToIntake → ToElement, Outake → CommitOutake
    X button: ToElement → CommitIntake
    Y button: CommitIntake → Transfer
    Right trigger: Control slide extension in ToElement state
     */
    public static enum RobotState {
        INIT,
        TO_INTAKE,
        TO_ELEMENT,
        COMMIT_INTAKE,
        TRANSFER,
        OUTAKE,
        COMMIT_OUTAKE
    }

    // Constants
    private static final double INTAKE_HORIZONTAL = 0.5;
    private static final double INTAKE_VERTICAL = 0.9;
    private static final double INTAKE_CLAW_OPEN = 0.7;
    private static final double INTAKE_CLAW_CLOSED = 0.2;
    private static final double OUTAKE_CLAW_OPEN = 0.7;
    private static final double OUTAKE_CLAW_CLOSED = 0.2;
    private static final double OUTAKE_ARM_NORMAL = 0.5;
    private static final double OUTAKE_ARM_RELEASE = 0.8;

    // Timing constants (in seconds)
    private static final double SERVO_MOVE_TIME = 0.5;
    private static final double SLIDE_MOVE_TIME = 0.7;

    // Button debounce variables
    private boolean wasAPressed = false;
    private boolean wasBPressed = false;
    private boolean wasXPressed = false;
    private boolean wasYPressed = false;

    private RobotState currentState = RobotState.INIT;
    private boolean stateInitialized = false;

    @Override
    public void runOpMode() throws InterruptedException {
        // Initialize hardware and timer
        initializeHardware();
        stateTimer = new ElapsedTime();

        waitForStart();

        while (opModeIsActive()) {
            // Handle state transitions
            updateState();

            // Execute current state logic
            executeState();

            // Update telemetry
            telemetry.addData("Current State", currentState);
            telemetry.addData("State Timer", stateTimer.seconds());
            telemetry.addData("Intake Slide Pos", intakeSlide.getCurrentPosition());
            telemetry.addData("Outtake Slide Pos", outtakeSlide.getCurrentPosition());
            telemetry.update();
        }
    }

    private void initializeHardware() {
        // Initialize motors
        intakeSlide = hardwareMap.get(DcMotor.class, "intakeSlide");
        outtakeSlide = hardwareMap.get(DcMotor.class, "outtakeSlide");

        // Configure motors
        intakeSlide.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        outtakeSlide.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        intakeSlide.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        outtakeSlide.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

        // Initialize servos
        intakeClaw = hardwareMap.get(Servo.class, "intakeClaw");
        outtakeClaw = hardwareMap.get(Servo.class, "outtakeClaw");
        intakeArm = hardwareMap.get(Servo.class, "intakeArm");
        outtakeArm = hardwareMap.get(Servo.class, "outtakeArm");
    }

    private void updateState() {
        // Handle button debouncing and state transitions
        boolean aPressed = gamepad1.a && !wasAPressed;
        boolean bPressed = gamepad1.b && !wasBPressed;
        boolean xPressed = gamepad1.x && !wasXPressed;
        boolean yPressed = gamepad1.y && !wasYPressed;

        wasAPressed = gamepad1.a;
        wasBPressed = gamepad1.b;
        wasXPressed = gamepad1.x;
        wasYPressed = gamepad1.y;

        switch (currentState) {
            case INIT:
                if (aPressed) {
                    currentState = RobotState.TO_INTAKE;
                    stateInitialized = false;
                    stateTimer.reset();
                }
                break;

            case TO_INTAKE:
                if (bPressed) {
                    currentState = RobotState.TO_ELEMENT;
                    stateInitialized = false;
                    stateTimer.reset();
                }
                break;

            case TO_ELEMENT:
                if (xPressed) {
                    currentState = RobotState.COMMIT_INTAKE;
                    stateInitialized = false;
                    stateTimer.reset();
                }
                break;

            case COMMIT_INTAKE:
                if (yPressed) {
                    currentState = RobotState.TRANSFER;
                    stateInitialized = false;
                    transferStep = 0;
                    stateTimer.reset();
                }
                break;

            case TRANSFER:
                if (aPressed && transferStep >= 4) {  // Only allow transition when transfer is complete
                    currentState = RobotState.OUTAKE;
                    stateInitialized = false;
                    outakeStep = 0;
                    stateTimer.reset();
                }
                break;

            case OUTAKE:
                if (bPressed) {
                    currentState = RobotState.COMMIT_OUTAKE;
                    stateInitialized = false;
                    stateTimer.reset();
                }
                break;

            case COMMIT_OUTAKE:
                if (isStateComplete()) {
                    currentState = RobotState.INIT;
                    stateInitialized = false;
                    stateTimer.reset();
                }
                break;
        }
    }

    private void executeState() {
        switch (currentState) {
            case INIT:
                if (!stateInitialized) {
                    intakeArm.setPosition(INTAKE_VERTICAL);
                    intakeClaw.setPosition(INTAKE_CLAW_OPEN);
                    outtakeArm.setPosition(OUTAKE_ARM_NORMAL);
                    outtakeClaw.setPosition(OUTAKE_CLAW_OPEN);
                    intakeSlide.setTargetPosition(0);
                    outtakeSlide.setTargetPosition(0);
                    stateInitialized = true;
                }
                break;

            case TO_INTAKE:
                if (!stateInitialized) {
                    intakeArm.setPosition(INTAKE_HORIZONTAL);
                    intakeSlide.setTargetPosition(0);
                    stateInitialized = true;
                }
                break;

            case TO_ELEMENT:
                int slideExtension = (int)(gamepad1.right_trigger * 1000);
                intakeSlide.setTargetPosition(slideExtension);
                break;

            case COMMIT_INTAKE:
                if (!stateInitialized) {
                    intakeClaw.setPosition(INTAKE_CLAW_CLOSED);
                    stateInitialized = true;
                }
                break;

            case TRANSFER:

                switch (transferStep) {
                    case 0:
                        if (!stateInitialized) {
                            intakeSlide.setTargetPosition(intakeSlide.getCurrentPosition() - 200);
                            stateTimer.reset();
                            stateInitialized = true;
                        }
                        if (stateTimer.seconds() > SLIDE_MOVE_TIME) {
                            transferStep++;
                            stateTimer.reset();
                        }
                        break;

                    case 1:
                        intakeArm.setPosition(INTAKE_VERTICAL);
                        if (stateTimer.seconds() > SERVO_MOVE_TIME) {
                            transferStep++;
                            stateTimer.reset();
                        }
                        break;

                    case 2:
                        outtakeClaw.setPosition(OUTAKE_CLAW_OPEN);
                        if (stateTimer.seconds() > SERVO_MOVE_TIME) {
                            transferStep++;
                            stateTimer.reset();
                        }
                        break;

                    case 3:
                        outtakeClaw.setPosition(OUTAKE_CLAW_CLOSED);
                        if (stateTimer.seconds() > SERVO_MOVE_TIME) {
                            transferStep++;
                            stateTimer.reset();
                        }
                        break;

                    case 4:
                        intakeClaw.setPosition(INTAKE_CLAW_OPEN);
                        if (stateTimer.seconds() > SERVO_MOVE_TIME) {
                            transferStep++;
                        }
                        break;
                }
                break;

            case OUTAKE:
                switch (outakeStep) {
                    case 0:
                        if (!stateInitialized) {
                            outtakeSlide.setTargetPosition(1000);
                            stateTimer.reset();
                            stateInitialized = true;
                        }
                        if (stateTimer.seconds() > SLIDE_MOVE_TIME) {
                            outakeStep++;
                        }
                        break;
                }
                break;

            case COMMIT_OUTAKE:
                if (!stateInitialized) {
                    outtakeArm.setPosition(OUTAKE_ARM_RELEASE);
                    if (stateTimer.seconds() > SERVO_MOVE_TIME) {
                        outtakeClaw.setPosition(OUTAKE_CLAW_OPEN);
                        if (stateTimer.seconds() > SERVO_MOVE_TIME * 2) {
                            outtakeArm.setPosition(OUTAKE_ARM_NORMAL);
                            outtakeSlide.setTargetPosition(0);
                            stateInitialized = true;
                        }
                    }
                }
                break;
        }
    }

    private boolean isStateComplete() {
        switch (currentState) {
            case COMMIT_OUTAKE:
                return !intakeSlide.isBusy() && !outtakeSlide.isBusy() &&
                        Math.abs(outtakeSlide.getCurrentPosition()) < 10 &&
                        stateTimer.seconds() > SERVO_MOVE_TIME * 3;
            default:
                return false;
        }
    }
}