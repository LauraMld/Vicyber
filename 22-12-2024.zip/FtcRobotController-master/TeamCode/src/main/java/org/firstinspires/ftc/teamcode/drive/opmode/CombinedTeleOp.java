package org.firstinspires.ftc.teamcode.drive.opmode;

import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;

@TeleOp(name = "Combined Robot TeleOp", group = "Robot")
public class CombinedTeleOp extends LinearOpMode {
    // State machine hardware
    private DcMotor intakeSlide;
    private DcMotor outtakeSlide;
    private Servo intakeClaw;
    private Servo outtakeClaw;
    private Servo intakeArm;
    private Servo outtakeArm;

    // Timer for state transitions
    private ElapsedTime stateTimer;
    private int transferStep = 0;
    private int outakeStep = 0;

    // State enum
    public static enum RobotState {
        INIT,
        TO_INTAKE,
        TO_ELEMENT,
        COMMIT_INTAKE,
        TRANSFER,
        OUTAKE,
        COMMIT_OUTAKE
    }

    // Constants for state machine
    private static final double INTAKE_HORIZONTAL = 0.5;
    private static final double INTAKE_VERTICAL = 0.9;
    private static final double INTAKE_CLAW_OPEN = 0.7;
    private static final double INTAKE_CLAW_CLOSED = 0.2;
    private static final double OUTAKE_CLAW_OPEN = 0.7;
    private static final double OUTAKE_CLAW_CLOSED = 0.2;
    private static final double OUTAKE_ARM_NORMAL = 0.5;
    private static final double OUTAKE_ARM_RELEASE = 0.8;
    private static final double SERVO_MOVE_TIME = 0.5;
    private static final double SLIDE_MOVE_TIME = 0.7;


    // State machine variables
    private double speedMultiplier = 1.0;
    private RobotState currentState = RobotState.INIT;
    private boolean stateInitialized = false;
    private boolean wasAPressed = false;
    private boolean wasBPressed = false;
    private boolean wasXPressed = false;
    private boolean wasYPressed = false;

    @Override
    public void runOpMode() throws InterruptedException {
        // Initialize RoadRunner drive
        SampleMecanumDrive drive = new SampleMecanumDrive(hardwareMap);

        // Initialize state machine hardware
        initializeStateHardware();
        stateTimer = new ElapsedTime();

        waitForStart();

        while (opModeIsActive()) {
            // Update drive system
            // Read pose
            Pose2d poseEstimate = drive.getPoseEstimate();

            updateDriveSpeed();
            // Create drive vector from gamepad inputs
            Pose2d driveVector = new Pose2d(
                    -gamepad1.left_stick_y*speedMultiplier,
                    -gamepad1.left_stick_x*speedMultiplier,
                    -gamepad1.right_stick_x
            );

            // Set drive power
            drive.setWeightedDrivePower(driveVector);

            // Update RoadRunner
            drive.update();

            // Update state machine
            updateState();
            executeState();

            // Update telemetry
            telemetry.addData("Speed Multiplier", String.format("%.2fx", speedMultiplier));
            telemetry.addData("Drive Position", "X: %.2f Y: %.2f Heading: %.2f",
                    poseEstimate.getX(), poseEstimate.getY(), Math.toDegrees(poseEstimate.getHeading()));
            telemetry.addData("Current State", currentState);
            telemetry.addData("State Timer", stateTimer.seconds());
            telemetry.addData("Intake Slide Pos", intakeSlide.getCurrentPosition());
            telemetry.addData("Outtake Slide Pos", outtakeSlide.getCurrentPosition());
            telemetry.update();
        }
    }

    private void initializeStateHardware() {
        // Initialize motors
        intakeSlide = hardwareMap.get(DcMotor.class, "intakeSlide");
        outtakeSlide = hardwareMap.get(DcMotor.class, "outtakeSlide");

        // Configure motors
        intakeSlide.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        outtakeSlide.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        intakeSlide.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        outtakeSlide.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

        // Initialize servos
        intakeClaw = hardwareMap.get(Servo.class, "intakeClaw");
        outtakeClaw = hardwareMap.get(Servo.class, "outtakeClaw");
        intakeArm = hardwareMap.get(Servo.class, "intakeArm");
        outtakeArm = hardwareMap.get(Servo.class, "outtakeArm");
    }
    private void updateDriveSpeed() {
        ///Varianta mai eleganta fara while, o las aici sa fie.
        ///Sigur nu se pierde input de la alte butoane?

        ///speedMultiplier = gamepad1.dpad_down ? 0.3 : 1.0;
        while(gamepad1.dpad_down){
            speedMultiplier=0.3;
        }
        speedMultiplier=1.0;
    }

    private void updateState() {

        boolean aPressed = gamepad1.a && !wasAPressed;
        boolean bPressed = gamepad1.b && !wasBPressed;
        boolean xPressed = gamepad1.x && !wasXPressed;
        boolean yPressed = gamepad1.y && !wasYPressed;

        wasAPressed = gamepad1.a;
        wasBPressed = gamepad1.b;
        wasXPressed = gamepad1.x;
        wasYPressed = gamepad1.y;

        switch (currentState) {
            case INIT:
                if (aPressed) {
                    currentState = RobotState.TO_INTAKE;
                    stateInitialized = false;
                    stateTimer.reset();
                }
                break;

            case TO_INTAKE:
                if (bPressed) {
                    currentState = RobotState.TO_ELEMENT;
                    stateInitialized = false;
                    stateTimer.reset();
                }
                break;

            case TO_ELEMENT:
                if (xPressed) {
                    currentState = RobotState.COMMIT_INTAKE;
                    stateInitialized = false;
                    stateTimer.reset();
                }
                break;

            case COMMIT_INTAKE:
                if (yPressed) {
                    currentState = RobotState.TRANSFER;
                    stateInitialized = false;
                    transferStep = 0;
                    stateTimer.reset();
                }
                break;

            case TRANSFER:
                if (aPressed && transferStep >= 4) {
                    currentState = RobotState.OUTAKE;
                    stateInitialized = false;
                    outakeStep = 0;
                    stateTimer.reset();
                }
                break;

            case OUTAKE:
                if (bPressed) {
                    currentState = RobotState.COMMIT_OUTAKE;
                    stateInitialized = false;
                    stateTimer.reset();
                }
                break;

            case COMMIT_OUTAKE:
                if (isStateComplete()) {
                    currentState = RobotState.INIT;
                    stateInitialized = false;
                    stateTimer.reset();
                }
                break;
        }
    }

    private void executeState() {
        switch (currentState) {
            case INIT:
                if (!stateInitialized) {
                    intakeArm.setPosition(INTAKE_VERTICAL);
                    intakeClaw.setPosition(INTAKE_CLAW_OPEN);
                    outtakeArm.setPosition(OUTAKE_ARM_NORMAL);
                    outtakeClaw.setPosition(OUTAKE_CLAW_OPEN);
                    intakeSlide.setTargetPosition(0);
                    outtakeSlide.setTargetPosition(0);
                    stateInitialized = true;
                }
                break;

            case TO_INTAKE:
                if (!stateInitialized) {
                    intakeArm.setPosition(INTAKE_HORIZONTAL);
                    intakeSlide.setTargetPosition(0);
                    stateInitialized = true;
                }
                break;

            case TO_ELEMENT:
                int slideExtension = (int)(gamepad1.right_trigger * 1000);
                intakeSlide.setTargetPosition(slideExtension);
                break;

            case COMMIT_INTAKE:
                if (!stateInitialized) {
                    intakeClaw.setPosition(INTAKE_CLAW_CLOSED);
                    stateInitialized = true;
                }
                break;

            case TRANSFER:
                handleTransferState();
                break;

            case OUTAKE:
                handleOutakeState();
                break;

            case COMMIT_OUTAKE:
                handleCommitOutakeState();
                break;
        }
    }

    private void handleTransferState() {
        switch (transferStep) {
            case 0:
                if (!stateInitialized) {
                    intakeSlide.setTargetPosition(intakeSlide.getCurrentPosition() - 200);
                    stateTimer.reset();
                    stateInitialized = true;
                }
                if (stateTimer.seconds() > SLIDE_MOVE_TIME) {
                    transferStep++;
                    stateTimer.reset();
                }
                break;

            case 1:
                intakeArm.setPosition(INTAKE_VERTICAL);
                if (stateTimer.seconds() > SERVO_MOVE_TIME) {
                    transferStep++;
                    stateTimer.reset();
                }
                break;

            case 2:
                outtakeClaw.setPosition(OUTAKE_CLAW_OPEN);
                if (stateTimer.seconds() > SERVO_MOVE_TIME) {
                    transferStep++;
                    stateTimer.reset();
                }
                break;

            case 3:
                outtakeClaw.setPosition(OUTAKE_CLAW_CLOSED);
                if (stateTimer.seconds() > SERVO_MOVE_TIME) {
                    transferStep++;
                    stateTimer.reset();
                }
                break;

            case 4:
                intakeClaw.setPosition(INTAKE_CLAW_OPEN);
                if (stateTimer.seconds() > SERVO_MOVE_TIME) {
                    transferStep++;
                }
                break;
        }
    }

    private void handleOutakeState() {
        if (!stateInitialized) {
            outtakeSlide.setTargetPosition(1000); // Adjust value as needed
            stateTimer.reset();
            stateInitialized = true;
        }
        if (stateTimer.seconds() > SLIDE_MOVE_TIME) {
            outakeStep++;
        }
    }

    private void handleCommitOutakeState() {
        if (!stateInitialized) {
            outtakeArm.setPosition(OUTAKE_ARM_RELEASE);
            if (stateTimer.seconds() > SERVO_MOVE_TIME) {
                outtakeClaw.setPosition(OUTAKE_CLAW_OPEN);
                if (stateTimer.seconds() > SERVO_MOVE_TIME * 2) {
                    outtakeArm.setPosition(OUTAKE_ARM_NORMAL);
                    outtakeSlide.setTargetPosition(0);
                    stateInitialized = true;
                }
            }
        }
    }

    private boolean isStateComplete() {
        if (currentState == RobotState.COMMIT_OUTAKE) {
            return !intakeSlide.isBusy() &&
                    !outtakeSlide.isBusy() &&
                    Math.abs(outtakeSlide.getCurrentPosition()) < 10 &&
                    stateTimer.seconds() > SERVO_MOVE_TIME * 3;
        }
        return false;
    }
}